﻿Manual
Package 'clgrm' is writen by Yingbo Yuan, Dan Jiang and Ming Fang, 
When using this package, please cite "".

1. Running envionrment and compilation
	installation of mkl
	Downloading website: https://software.intel.com/en-us/mkl
	1.1 'clgrm_grm' compiling
		gcc clgrm_grm.c -I/(your_mkl_installed_path)/include/ \
		-Wl,--start-group /(your_mkl_installed_path)/mkl/lib/intel64/libmkl_intel_lp64.a \ 
		/(your_mkl_installed_path)/mkl/lib/intel64/libmkl_gnu_thread.a \
		/(your_mkl_installed_path)/mkl/lib/intel64/libmkl_core.a \
		/(your_mkl_installed_path)/lib/intel64/libiomp5.a -Wl,--end-group \
		-lpthread -lm -ldl -o clgrm_grm 
	1.2 'clgrm_index' compiling
		gcc clgrm_index.c -o clgrm_index
	1.3 'clgrm_mix' compiling
		gcc clgrm_combine.c -o clgrm_combine
	1.4  The excutable permision setting
		chmod a+x clgrm_* 
		
2. Input and output
	Input files in MACH output format (uncompressed)
	Output files format can be found in package
3. Running step
	3.1 Calculation GRM for each region 
		./clgrm_grm --in_file <inputFile> --weight_file <inputweightFile> --out_file <outfile> --threads_num <numberOfThreads>
		--in_file <inputFile> , Input files in MACH output format (uncompressed)
		--weight_file <inputweightFile> weight file, author can optionally set or not set this function, default value is 1, weigh can be set according to SNP effect, each line represents SNP number.
		--out_file <outfile> output file
		--threads_num <numberOfThreads> the number of threads, default 10
	3.2 Index for GRM
		./clgrm_index <inputfile> <indexfile>
		inputfile: input file 
		indexfile: output index file
                                Note that the software needs one index file making from eiher whole genotype file or from any part of genotype file.
	3.3 Merging all regions
		./clgrm_combine <infilelist>
		infilelist includes
 		|-----------------------------------------------------
		| /$your_out_path/outfilename (given by user)    
		| /$indexfile_path /indexfile
		| /'OutPath'/out1       
		| /'OutPath'/out2       
		| /'OutPath'/out3       
		| /'OutPath'/out4       
		| /'OutPath'/out5       
		|------------------------------------------------------
                                'outfilename' can be any name given by user; out1-out5 are prefix of the out files.  
   		Note: when spliting, if taking SNP weight ointo account, then the weight file 'weightfile' should be splited accordingly.

	3.4 Note
		You can split data according to region to reduce the RAM requirement if your data is too big,
		f.i. split your data into 5 parts, named with  out1-5,
		    you can repeat step 3.1 to produce
			              'out5.pq' 'out5.xx'
			              'out5.pq' 'out5.xx'
				 .....
			              'out5.pq' 'out5.xx'
4 Example:
	4.1 The example has 100 individuals, 250 SNPs (no weightfile), we are going to 
		4.1.1 Run the whole genotype file
		(1) ./clgrm_grm --in_file test.mldose_all.txt --out_file outall --threads_num 10
			Outfiles: 'outall.pq' and 'ouall.xx'
		(2) ./clgrm_index 'test.mldose_all.txt' 'all_index.txt'
                                                Outfile: 'all_index.txt'
		(3 ) ./clgrm_combine 'infilepath.txt'
		   'infilepath' include followings:
		   ----------------------------------------------------------------------------------------
		   |   'all_combine_no_weight.Gout' (the name of the out Gmatrix given by user)
		   |   'all_index.txt' (the index file)		     
		   |   'outall' (prefix of the out file)			     |
		   |----------------------------------------------------------------------------------------
			
		  Open the out G-matrix file 'all_combine_no_weight.Gout', we can see:
			1 1 0.91869515
			1 2 -0.0036033706
			1 3 -0.15874796
			1 4 -0.033527479
			1 5 -0.088203646
			1 6 -0.11582203
			1 7 0.039209522
			1 8 0.09967757
			1 9 -0.15416269
			1 10 -0.14053957
			1 11 0.1496703
		4.1.2 Split the genotype file into 5 parts
		(1.1) ./clgrm_grm --in_file test.mldose1.txt --out_file out1 --threads_num 10
			Output files: out1.pq ou1.xx
		(1.2) ./clgrm_grm --in_file test.mldose2.txt --out_file out2 --threads_num 10
			Output files: out1.pq ou2.xx
		(1.3) ./clgrm_grm --in_file test.mldose3.txt --out_file out3 --threads_num 10
			Output files: out1.pq ou3.xx
		(1.4) ./clgrm_grm --in_file test.mldose4.txt --out_file out4 --threads_num 10
			Output files: out1.pq ou4.xx
		(1.5) ./clgrm_grm --in_file test.mldose5.txt --out_file out5 --threads_num 10
			Output files: out1.pq ou5.xx
		(1.6). /clgrm_index test.mldose_all.txt all_index.txt
			Output files: all_index.txt.  
		(1.7) ./clgrm_combine 'infilepath'
		   'infilepath' file includes followings:
		   ---------------------------------------------------------------------------
		   |  'combine_no_weight.Gout': name of the output G-matrix file
		   |   'all_index.txt'		     
		   |   'out1'             	         
		   |   'out2'            	         
		   |   'out3'            	         
		   |   'out4'            	         
		   |   'out5'            	         
		   |--------------------------------------------------------------------------
			
		we can see：
			1 1 0.91869605
			1 2 -0.0036026337
			1 3 -0.15874834
			1 4 -0.033526622
			1 5 -0.088202052 
			1 6 -0.11582007
			1 7 0.03920842
			1 8 0.099677332
			1 9 -0.15416245
			1 10 -0.14053896
			1 11 0.14967142
	4.2  100 individuals，250 SNPs (with weightfile, taking SNP weight into account)
		Suppose each SNP having weight 0.004 (should be sum)
		4.2.1 Processing one of the spliting genotype file
		(1) ./clgrm_grm --in_file test.mldose_all.txt --weight_file weightfile.txt --out_file out_weight --threads_num 10
			Outfiles: out_weight.pq out_weight.xx
		(2) ./clgrm_index test.mldose_all.txt all_index.txt
			Outfile: all_index.txt
		(3) ./clgrm_combine 'infilepath'
		   'infilepath' file includes followings:
		   -------------------------------------------------------------------------------
		   |   all_combine_weight.Gout (the name of out file given by author)
		   |   all_index.txt		 
		   |   out_weight		 
		   |------------------------------------------------------------------------------
			we can see
			1 1 0.031111155
			1 2 -0.00012193722
			1 3 -0.0053758994
			1 4 -0.0011353476
			1 5 -0.002986952
			1 6 -0.0039222008
			1 7 0.0013277794
			1 8 0.0033755333
			1 9 -0.0052206367
			1 10 -0.0047592614
			1 11 0.005068515
		4.2.2 Spliting input files into 5 parts
		(1.1) ./clgrm_grm --in_file test.mldose1.txt --weight_file weightfile1.txt --out_file out1_weight --threads_num 10
			Outfile: out1_weight.pq ou1_weight.xx
		(1.2) ./clgrm_grm --in_file test.mldose2.txt --weight_file weightfile2.txt --out_file out2_weight --threads_num 10
			Outfile: out2_weight.pq ou2_weight.xx
		(1.3) ./clgrm_grm --in_file test.mldose3.txt --weight_file weightfile3.txt --out_file out3_weight --threads_num 10
			Outfile: out3_weight.pq ou3_weight.xx
		(1.4) ./clgrm_grm --in_file test.mldose4.txt --weight_file weightfile4.txt --out_file out4_weight --threads_num 10
			Outfile: out4_weight.pq ou4_weight.xx
		(1.5) ./clgrm_grm --in_file test.mldose5.txt --weight_file weightfile5.txt --out_file out5_weight --threads_num 10
			Outfile: out5_weight.pq ou5_weight.xx
		(1.6) ./clgrm_index test.mldose_all.txt all_index.txt
			Outfile: all_index.txt
		(1.7) ./clgrm_combine 'infilepath'
		   'infilepath' file includes followings:
		   -------------------------------
		   |   1_5_combine_weight.Gout   
		   |   all_index.txt		     
		   |   out1_weight               
		   |   out2_weight            	 
		   |   out3_weight            	 
		   |   out4_weight            	 
		   |   out5_weight            	 
		   -------------------------------
			We can see
			1 1 0.031111119
			1 2 -0.00012201037
			1 3 -0.0053759241
			1 4 -0.0011353843
			1 5 -0.0029869685
			1 6 -0.0039222133
			1 7 0.0013277836
			1 8 0.0033755132
			1 9 -0.0052206409
			1 10 -0.0047592861
			1 11 0.0050685112	
